package com.project.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
