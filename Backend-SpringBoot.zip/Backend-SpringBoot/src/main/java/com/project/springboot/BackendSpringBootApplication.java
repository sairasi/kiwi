package com.project.springboot;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.project.springboot.model.User;
import com.project.springboot.repository.UserRepository;

@SpringBootApplication
public class BackendSpringBootApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(BackendSpringBootApplication.class, args);
	}
	
	@Autowired
	private UserRepository userRepository;
	
	@Override
	
	public void run(String...  args) throws Exception{
		this.userRepository.save(new User("preethi","rao","pree12@gmail.com"));
		this.userRepository.save(new User("neha","gupta","guptaneha@gmail.com"));
		this.userRepository.save(new User("preethi","S","reddypreethi@gmail.com"));


	}
	
	

}
